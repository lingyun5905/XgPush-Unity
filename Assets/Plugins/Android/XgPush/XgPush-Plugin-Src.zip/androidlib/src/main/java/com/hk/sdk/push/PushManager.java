package com.hk.sdk.push;

import android.content.Context;
import android.util.Log;

import com.tencent.android.tpush.XGIOperateCallback;
import com.tencent.android.tpush.XGPushConfig;
import com.tencent.android.tpush.XGPushManager;
import com.unity3d.player.UnityPlayer;

import org.json.JSONObject;

import java.util.HashMap;

/**
 * 推送管理类
 */
public class PushManager {
    private static String TAG = "PushManager";
    private static PushManager instance = new PushManager();
    private Context m_Context;
    private String m_U3dGameObject;
    private String m_U3dCallback;

    public static PushManager getInstance()
    {
        return instance;
    }

    private PushManager() {
    }

    /**
     * 初始化
     * @param gameObject
     * @param callback
     */
    public void init(String gameObject, String callback)
    {
        this.m_Context = UnityPlayer.currentActivity.getApplicationContext();
        this.m_U3dGameObject = gameObject;
        this.m_U3dCallback = callback;
    }

    /**
     * 设置accessId
     * @param accessId
     */
    public void setAccessId(long accessId) {
        XGPushConfig.setAccessId(m_Context, accessId);
    }

    /**
     * 获得accessId
     * @return
     */
    public long getAccessId() {
        return XGPushConfig.getAccessId(m_Context);
    }

    /**
     * 设置accessKey
     * @param accessKey
     */
    public void setAccessKey(String accessKey) {
        XGPushConfig.setAccessKey(m_Context, accessKey);
    }

    /**
     * 获取AccessKey
     * @return
     */
    public String getAccessKey() {

        return XGPushConfig.getAccessKey(m_Context);
    }

    /**
     * 设置小米appid
     * @param appId
     */
    public void setMiPushAppId(String appId) {
        XGPushConfig.setMiPushAppId(m_Context, appId);
    }

    /**
     * 设置小米appkey
     * @param appkey
     */
    public void setMiPushAppKey(String appkey) {
        XGPushConfig.setMiPushAppKey(m_Context, appkey);
    }

    /**
     * 设置魅族AppId
     * @param appId
     */
    public void setMzPushAppId(String appId) {
        XGPushConfig.setMzPushAppId(m_Context, appId);
    }

    /**
     * 设置魅族Appkey
     * @param appKey
     */
    public void setMzPushAppKey(String appKey) {
        XGPushConfig.setMzPushAppKey(m_Context, appKey);
    }

    /**
     * 设置安装渠道
     * @param channel
     */
    public void setInstallChannel(String channel) {
        XGPushConfig.setInstallChannel(m_Context, channel);
    }

    /**
     * 获得安装渠道
     * @return
     */
    public String getInstallChannel() {
        return XGPushConfig.getInstallChannel(m_Context);
    }

    /**
     * 设置华为手机调试模式
     * @param isDebug
     */
    public void setHuaweiDebug(boolean isDebug) {
        XGPushConfig.setHuaweiDebug(isDebug);
    }

    /**
     * 是否开启调试
     * @param isEnable
     */
    public void enableDebug(boolean isEnable) {
        XGPushConfig.enableDebug(m_Context, isEnable);
    }

    /**
     * 获取设备的token，只有注册成功才能获取到正常的结果
     * @return
     */
    public String getToken() {
        return XGPushConfig.getToken(m_Context);
    }

    /**
     *  注册信鸽推送
     */
    public void registerPush() {
        /*
        注册信鸽服务的接口
        如果仅仅需要发推送消息调用这段代码即可
        */
        XGPushManager.registerPush(m_Context, new XGIOperateCallback() {
            @Override
            public void onSuccess(Object data, int flag) {
                Log.d(TAG, "注册成功，设备token为：" + data);
                UnityPlayer.UnitySendMessage(m_U3dGameObject, m_U3dCallback, getMethodJson("OnStartFinish", true, null));
            }
            @Override
            public void onFail(Object data, int errCode, String msg) {
                Log.d(TAG, "注册失败，错误码：" + errCode + ",错误信息：" + msg);
                UnityPlayer.UnitySendMessage(m_U3dGameObject, m_U3dCallback, getMethodJson("OnStartFinish", false, msg));
            }
        });
    }

    private String getMethodJson(String method, boolean isSuccess, String msg) {
        HashMap<String, Object> map = new HashMap();
        map.put("method", method);
        map.put("success", isSuccess);
        if (msg !=null && !msg.isEmpty()) {
            map.put("msg", msg);
        }
        JSONObject json = new JSONObject(map);
        return  json.toString();
    }

    /**
     * 反注册信鸽推送
     */
    public void unregisterPush(){

        XGPushManager.unregisterPush(m_Context, new XGIOperateCallback(){

            @Override
            public void onSuccess(Object data, int i) {
                Log.d(TAG, "反注册成功 ：" + data);
                UnityPlayer.UnitySendMessage(m_U3dGameObject, m_U3dCallback, getMethodJson("OnStopFinish", true, null));
            }

            @Override
            public void onFail(Object data, int errCode, String msg) {
                Log.d(TAG, "反注册成功，错误码：" + errCode + ",错误信息：" + msg);
                UnityPlayer.UnitySendMessage(m_U3dGameObject, m_U3dCallback, getMethodJson("OnStopFinish", false, msg));
            }
        });
    }

    /**
     * 绑定账号,推荐有帐号体系的APP使用(此接口会覆盖设备之前绑定过的账号)
     * @param account
     */
    public void bindAccount(String account) {
        XGPushManager.bindAccount(m_Context, account);
    }

    /**
     * 绑定账号,推荐有帐号体系的APP使用(此接口保留之前的账号，只做增加操作，
     * 一个token下最多只能有3个账号超过限制会自动顶掉之前绑定的账号)
     * @param account
     */
    public void appendAccount(String account) {
        XGPushManager.appendAccount(m_Context, account);
    }

    /**
     * 解绑指定账号
     * @param account
     */
    public void delAccount(String account) {
        XGPushManager.delAccount(m_Context, account);
    }

    /**
     * 设置标签
     * @param tag
     */
    public void setTag(String tag) {
        XGPushManager.setTag(m_Context, tag);
    }

    /**
     * 删除标签
     * @param tag
     */
    public void deleteTag(String tag) {
        XGPushManager.deleteTag(m_Context, tag);
    }
}
